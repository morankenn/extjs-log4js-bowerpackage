Log4js-ext 
========================================================================

Log4js-ext is an Open Source library that provides logging 
support for javascript in an ExtJs environment.

You can go to http://code.google.com/p/log4js-ext/ for additional information.

Instructions
============
Please, go to http://code.google.com/p/log4js-ext/ for information on how
to use Log4js-ext

License
============
This software is distributed under the terms of the GNU Lesser General 
Public License v3 (see the 'lgpl.txt' file for details).

Commercial use is permitted to the extent that the code/component(s)
do NOT become part of another Open Source or Commercially developed
licensed development library or toolkit without explicit permission.

This software uses the ExtJs library (http://www.sencha.com).
For information on the ExtJs license, go to their website.
